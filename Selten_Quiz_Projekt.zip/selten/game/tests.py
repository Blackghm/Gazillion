from django.test import TestCase
from django.core.management import call_command
from .models import Attempt,Response
from .views import norm
class GameTests(TestCase):
    def setUp(self): call_command('seed',verbosity=0)
    def test_normalize(self): self.assertEqual(norm('  ÖSTERREICH '),'oesterreich')
    def test_play_and_replay(self):
        self.client.get('/')
        self.client.post('/spielen/')
        a=Attempt.objects.get()
        for q in a.day.question_set.all():
            self.client.post('/spielen/',{'question':q.pk,'answer':q.answer_set.first().label})
        a.refresh_from_db()
        self.assertTrue(a.finished)
        self.assertEqual(Response.objects.count(),5)
        self.client.post('/spielen/')
        self.assertEqual(Attempt.objects.count(),1)
        self.assertEqual(self.client.get('/ergebnis/').status_code,200)
    def test_duplicate(self):
        self.client.get('/'); self.client.post('/spielen/')
        q=Attempt.objects.get().day.question_set.first()
        for _ in range(2): self.client.post('/spielen/',{'question':q.pk,'answer':'Unsinn'})
        self.assertEqual(Response.objects.count(),1)
    def test_future_not_visible(self):
        self.assertEqual(self.client.get('/rangliste/?tag=2099-01-01').status_code,200)
