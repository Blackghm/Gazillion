import uuid
from django.db import migrations,models
import django.db.models.deletion
from django.conf import settings
class Migration(migrations.Migration):
    initial=True
    dependencies=[migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations=[
      migrations.CreateModel(name='Day',fields=[('id',models.BigAutoField(primary_key=True,serialize=False)),('date',models.DateField(unique=True))]),
      migrations.CreateModel(name='Player',fields=[('id',models.UUIDField(primary_key=True,default=uuid.uuid4,editable=False,serialize=False)),('user',models.OneToOneField(to=settings.AUTH_USER_MODEL,on_delete=django.db.models.deletion.SET_NULL,null=True,blank=True))]),
      migrations.CreateModel(name='Question',fields=[('id',models.BigAutoField(primary_key=True,serialize=False)),('position',models.PositiveSmallIntegerField()),('text',models.CharField(max_length=500)),('note',models.TextField(blank=True)),('day',models.ForeignKey(to='game.day',on_delete=django.db.models.deletion.CASCADE))],options={'ordering':['position']}),
      migrations.CreateModel(name='Answer',fields=[('id',models.BigAutoField(primary_key=True,serialize=False)),('label',models.CharField(max_length=200)),('aliases',models.JSONField(default=list)),('points',models.PositiveSmallIntegerField(default=10)),('question',models.ForeignKey(to='game.question',on_delete=django.db.models.deletion.CASCADE))]),
      migrations.CreateModel(name='Attempt',fields=[('id',models.BigAutoField(primary_key=True,serialize=False)),('finished',models.BooleanField(default=False)),('total',models.PositiveIntegerField(default=0)),('day',models.ForeignKey(to='game.day',on_delete=django.db.models.deletion.CASCADE)),('player',models.ForeignKey(to='game.player',on_delete=django.db.models.deletion.CASCADE))]),
      migrations.CreateModel(name='Response',fields=[('id',models.BigAutoField(primary_key=True,serialize=False)),('raw',models.CharField(max_length=150,blank=True)),('points',models.PositiveSmallIntegerField(default=0)),('answer',models.ForeignKey(to='game.answer',null=True,blank=True,on_delete=django.db.models.deletion.PROTECT)),('attempt',models.ForeignKey(to='game.attempt',on_delete=django.db.models.deletion.CASCADE)),('question',models.ForeignKey(to='game.question',on_delete=django.db.models.deletion.PROTECT))]),
      migrations.AddConstraint(model_name='question',constraint=models.UniqueConstraint(fields=('day','position'),name='unique_day_position')),
      migrations.AddConstraint(model_name='attempt',constraint=models.UniqueConstraint(fields=('player','day'),name='one_attempt_daily')),
      migrations.AddConstraint(model_name='response',constraint=models.UniqueConstraint(fields=('attempt','question'),name='one_response')),
    ]
