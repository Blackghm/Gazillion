import unicodedata
from datetime import timedelta
from django.shortcuts import render,redirect
from django.utils import timezone
from django.db import transaction
from django.db.models import Count
from django.contrib.auth import login,logout
from django.contrib.auth.forms import AuthenticationForm,UserCreationForm
from django.contrib import messages
from django.views.decorators.http import require_POST
from .models import Player,Day,Question,Answer,Attempt,Response

def norm(value):
    value=unicodedata.normalize('NFKC',value).casefold().strip()
    for a,b in [('ä','ae'),('ö','oe'),('ü','ue'),('ß','ss')]: value=value.replace(a,b)
    return ' '.join(value.split())

def player(request):
    if request.user.is_authenticated:
        p,_=Player.objects.get_or_create(user=request.user)
        return p
    pid=request.session.get('player')
    p=Player.objects.filter(pk=pid).first() if pid else None
    if not p:
        p=Player.objects.create()
        request.session['player']=str(p.pk)
    return p

def today(): return timezone.localdate()
def close_old():
    Attempt.objects.filter(day__date__lt=today(),finished=False).update(finished=True)
def current_day(): return Day.objects.filter(date=today()).first()
def home(request):
    p=player(request); close_old()
    d=current_day()
    a=Attempt.objects.filter(player=p,day=d).first() if d else None
    dates=set(Attempt.objects.filter(player=p,finished=True).values_list('day__date',flat=True))
    cursor=today() if today() in dates else today()-timedelta(days=1)
    streak=0
    while cursor in dates:
        streak+=1; cursor-=timedelta(days=1)
    return render(request,'home.html',{'day':d,'attempt':a,'streak':streak})

def play(request):
    p=player(request); close_old(); d=current_day()
    if not d or d.question_set.count()!=5:
        messages.info(request,'Für heute ist noch keine vollständige Runde freigeschaltet.')
        return redirect('home')
    a=Attempt.objects.filter(player=p,day=d).first()
    if a and a.finished: return redirect('result')
    if not a:
        if request.method!='POST': return redirect('home')
        a,_=Attempt.objects.get_or_create(player=p,day=d)
        return redirect('play')
    with transaction.atomic():
        a=Attempt.objects.select_for_update().get(pk=a.pk)
        answered=a.response_set.values_list('question_id',flat=True)
        q=d.question_set.exclude(pk__in=answered).first()
        if not q:
            a.finished=True; a.save(update_fields=['finished'])
            return redirect('result')
        if request.method=='POST':
            if str(q.pk)!=request.POST.get('question'):
                return redirect('play')
            raw=request.POST.get('answer','').strip()[:150]
            match=None
            if raw:
                for candidate in q.answer_set.all():
                    if norm(raw) in {norm(x) for x in [candidate.label]+candidate.aliases}:
                        match=candidate; break
            Response.objects.create(attempt=a,question=q,raw=raw,answer=match,points=match.points if match else 0)
            a.total+=match.points if match else 0
            a.finished=a.response_set.count()==5
            a.save(update_fields=['total','finished'])
            return redirect('result' if a.finished else 'play')
    return render(request,'play.html',{'question':q})

def selected_day(request):
    date=request.GET.get('tag','')
    if date:
        try: return Day.objects.filter(date=date,date__lte=today()).first()
        except (ValueError,TypeError): return None
    return current_day()

def result(request):
    p=player(request); close_old(); d=selected_day(request)
    a=Attempt.objects.filter(player=p,day=d,finished=True).first()
    if not a: return redirect('home')
    others=Attempt.objects.filter(day=d,finished=True).exclude(pk=a.pk)
    count=others.count(); rank=1+others.filter(total__gt=a.total).count()
    pct=round(100*others.filter(total__lt=a.total).count()/count,1) if count else None
    rows=[]
    for r in a.response_set.select_related('question','answer').order_by('question__position'):
        n=Response.objects.filter(question=r.question).count()
        same=Response.objects.filter(question=r.question,answer=r.answer).count() if r.answer_id else 0
        rows.append({'r':r,'n':n,'same':same,'pct':round(100*same/n,1) if n else 0})
    return render(request,'result.html',{'a':a,'rows':rows,'rank':rank,'count':count+1,'pct':pct,'provisional':d.date==today()})

def board(request):
    close_old(); d=selected_day(request); rows=[]; previous=None; rank=0
    if d:
        for i,a in enumerate(Attempt.objects.filter(day=d,finished=True).select_related('player__user').order_by('-total','pk')[:100],1):
            if a.total!=previous: rank=i
            previous=a.total
            rows.append((rank,a))
    return render(request,'board.html',{'rows':rows,'day':d,'provisional':d and d.date==today(),'dates':Day.objects.filter(date__lte=today()).order_by('-date')[:30],'me':player(request).pk})

def account(request):
    guest=player(request)
    form=UserCreationForm(request.POST or None) if request.POST.get('mode')=='register' else AuthenticationForm(request,data=request.POST or None)
    if request.method=='POST' and form.is_valid():
        with transaction.atomic():
            if request.POST.get('mode')=='register':
                user=form.save(); guest.user=user; guest.save(update_fields=['user'])
            else:
                user=form.get_user(); dest,_=Player.objects.get_or_create(user=user)
                if guest.pk!=dest.pk and not guest.user_id:
                    for a in guest.attempt_set.all():
                        if not Attempt.objects.filter(player=dest,day=a.day).exists():
                            a.player=dest; a.save(update_fields=['player'])
            login(request,user)
        return redirect('home')
    return render(request,'account.html',{'form':form})
@require_POST
def logout_view(request):
    logout(request)
    return redirect('home')
def rules(request): return render(request,'rules.html')
