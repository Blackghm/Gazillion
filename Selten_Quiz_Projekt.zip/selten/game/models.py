import uuid
from django.db import models
from django.conf import settings
class Player(models.Model):
    id = models.UUIDField(primary_key=True,default=uuid.uuid4,editable=False)
    user = models.OneToOneField(settings.AUTH_USER_MODEL,null=True,blank=True,on_delete=models.SET_NULL)
    @property
    def nickname(self):
        return self.user.username if self.user_id else 'Gast-'+str(self.id)[:6]
class Day(models.Model):
    date = models.DateField(unique=True)
    def __str__(self): return str(self.date)
class Question(models.Model):
    day = models.ForeignKey(Day,on_delete=models.CASCADE)
    position = models.PositiveSmallIntegerField()
    text = models.CharField(max_length=500)
    note = models.TextField(blank=True)
    class Meta:
        ordering = ['position']
        constraints = [models.UniqueConstraint(fields=['day','position'],name='unique_day_position')]
class Answer(models.Model):
    question = models.ForeignKey(Question,on_delete=models.CASCADE)
    label = models.CharField(max_length=200)
    aliases = models.JSONField(default=list)
    points = models.PositiveSmallIntegerField(default=10)
class Attempt(models.Model):
    player = models.ForeignKey(Player,on_delete=models.CASCADE)
    day = models.ForeignKey(Day,on_delete=models.CASCADE)
    finished = models.BooleanField(default=False)
    total = models.PositiveIntegerField(default=0)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['player','day'],name='one_attempt_daily')]
class Response(models.Model):
    attempt = models.ForeignKey(Attempt,on_delete=models.CASCADE)
    question = models.ForeignKey(Question,on_delete=models.PROTECT)
    raw = models.CharField(max_length=150,blank=True)
    answer = models.ForeignKey(Answer,null=True,blank=True,on_delete=models.PROTECT)
    points = models.PositiveSmallIntegerField(default=0)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['attempt','question'],name='one_response')]
