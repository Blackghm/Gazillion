from datetime import timedelta,date
from django.core.management.base import BaseCommand
from django.utils import timezone
from game.models import Day,Question,Answer
DATA=[
('Nenne einen souveränen Staat, der an Deutschland grenzt.', [('Frankreich',10,[]),('Österreich',10,['Oesterreich']),('Schweiz',25,[]),('Polen',25,[]),('Niederlande',25,['Holland']),('Dänemark',50,[]),('Tschechien',50,['Tschechische Republik']),('Belgien',75,[]),('Luxemburg',100,[])]),
('Nenne einen Planeten unseres Sonnensystems (keinen Zwergplaneten).', [('Erde',10,[]),('Mars',10,[]),('Jupiter',25,[]),('Saturn',25,[]),('Venus',50,[]),('Merkur',75,[]),('Neptun',100,[]),('Uranus',75,[])]),
('Nenne eines der 16 deutschen Bundesländer.', [('Bayern',10,[]),('Berlin',10,[]),('Hamburg',25,[]),('Hessen',25,[]),('Nordrhein-Westfalen',25,['NRW']),('Baden-Württemberg',25,['Baden Wuerttemberg']),('Niedersachsen',50,[]),('Sachsen',50,[]),('Brandenburg',75,[]),('Bremen',75,[]),('Saarland',100,[]),('Thüringen',75,[]),('Sachsen-Anhalt',100,[]),('Schleswig-Holstein',75,[]),('Rheinland-Pfalz',50,[]),('Mecklenburg-Vorpommern',100,[])]),
('Nenne eines der zwölf westlichen Tierkreiszeichen.', [('Widder',25,[]),('Stier',25,[]),('Zwillinge',25,[]),('Krebs',25,[]),('Löwe',10,[]),('Jungfrau',50,[]),('Waage',50,[]),('Skorpion',25,[]),('Schütze',75,[]),('Steinbock',75,[]),('Wassermann',100,[]),('Fische',50,[])]),
('Nenne ein chemisches Element mit Ordnungszahl 1 bis 10.', [('Wasserstoff',10,['H']),('Helium',25,['He']),('Lithium',50,['Li']),('Beryllium',100,['Be']),('Bor',100,['B']),('Kohlenstoff',25,['C']),('Stickstoff',50,['N']),('Sauerstoff',10,['O']),('Fluor',75,['F']),('Neon',75,['Ne'])]),
('Nenne einen Monat mit genau 30 Tagen.', [('April',25,[]),('Juni',25,[]),('September',75,[]),('November',100,[])]),
('Nenne eine der sechs offiziellen Amtssprachen der Vereinten Nationen.', [('Englisch',10,[]),('Französisch',25,[]),('Spanisch',25,[]),('Russisch',75,[]),('Arabisch',100,[]),('Chinesisch',50,['Mandarin'])]),
('Nenne einen souveränen Staat, der an Portugal grenzt.', [('Spanien',100,[])]),
('Nenne eine der fünf kanonischen platonischen Körperarten.', [('Tetraeder',25,[]),('Hexaeder',10,['Würfel']),('Oktaeder',50,[]),('Dodekaeder',75,[]),('Ikosaeder',100,[])]),
('Nenne eine der vier Basen der DNA.', [('Adenin',25,[]),('Thymin',50,[]),('Guanin',75,[]),('Cytosin',100,[])]),
('Nenne einen der vier größten Jupitermonde (Galileische Monde).', [('Io',25,[]),('Europa',10,[]),('Ganymed',75,['Ganymedes']),('Kallisto',100,['Callisto'])]),
('Nenne eines der drei baltischen Länder.', [('Estland',25,[]),('Lettland',75,[]),('Litauen',100,[])]),
('Nenne einen der fünf Großen Seen Nordamerikas.', [('Oberer See',100,['Lake Superior','Superior']),('Michigansee',25,['Lake Michigan','Michigan']),('Huronsee',75,['Lake Huron','Huron']),('Eriesee',50,['Lake Erie','Erie']),('Ontariosee',25,['Lake Ontario','Ontario'])]),
('Nenne einen der vier Grand-Slam-Tenniswettbewerbe.', [('Australian Open',50,[]),('French Open',75,['Roland Garros']),('Wimbledon',10,[]),('US Open',100,['U.S. Open'])]),
('Nenne eine der vier klassischen Himmelsrichtungen.', [('Norden',10,['Nord']),('Osten',50,['Ost']),('Süden',25,['Süd']),('Westen',75,['West'])]),
('Nenne einen souveränen Staat, der an die Schweiz grenzt.', [('Deutschland',10,[]),('Frankreich',25,[]),('Italien',25,[]),('Österreich',75,[]),('Liechtenstein',100,[])])]
class Command(BaseCommand):
    help='Erstellt sieben Tage mit redaktionellen Demo-Inhalten; vorhandene Tage bleiben unverändert.'
    def add_arguments(self,parser):
        parser.add_argument('--start',default='')
    def handle(self,*args,**opts):
        start=date.fromisoformat(opts['start']) if opts['start'] else timezone.localdate()
        for offset in range(7):
            day,created=Day.objects.get_or_create(date=start+timedelta(days=offset))
            if not created: continue
            for position in range(1,6):
                text,answers=DATA[(offset*5+position-1)%len(DATA)]
                q=Question.objects.create(day=day,position=position,text=text,note='Demo; Seltenheit redaktionell geschätzt. Vor öffentlichem Betrieb fachlich und auf Alias-Vollständigkeit prüfen.')
                for label,points,aliases in answers:
                    Answer.objects.create(question=q,label=label,points=points,aliases=aliases)
        self.stdout.write(self.style.SUCCESS('Sieben Tage vorbereitet. Demo-Inhalte vor Veröffentlichung prüfen.'))
