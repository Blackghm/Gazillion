from django.contrib import admin
from .models import Day,Question,Answer,Attempt,Response,Player
class AnswerInline(admin.TabularInline):
    model=Answer
    extra=0
@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display=('day','position','text')
    list_filter=('day',)
    inlines=[AnswerInline]
admin.site.register([Day,Attempt,Response,Player])
