from django.contrib import admin
from django.urls import path
from game import views
urlpatterns = [path('admin/',admin.site.urls),path('',views.home,name='home'),path('spielen/',views.play,name='play'),path('ergebnis/',views.result,name='result'),path('rangliste/',views.board,name='board'),path('konto/',views.account,name='account'),path('abmelden/',views.logout_view,name='logout'),path('regeln/',views.rules,name='rules')]
