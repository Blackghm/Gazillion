# Selten — tägliches Quiz

Eigenständiger Django-Prototyp: 5 Fragen täglich, serverseitige Punkte, echte Rangliste, Gastspiel, optionale Konten und Streaks. Keine erfundenen Mitspieler.

## Lokal starten
Python 3.11 oder neuer. Befehle im Projektordner ausführen.

```sh
python -m venv .venv
```
Aktivieren: Windows `.venv\Scripts\activate`, macOS/Linux `source .venv/bin/activate`.

```sh
pip install -r requirements.txt
```
Lokale Umgebungsvariable setzen: macOS/Linux `export DEBUG=1`; PowerShell `$env:DEBUG="1"`; Windows cmd `set DEBUG=1`.

```sh
python manage.py migrate
python manage.py seed
python manage.py createsuperuser
python manage.py runserver
```
Öffnen: http://127.0.0.1:8000 — Verwaltung: /admin/

## GitHub
ZIP entpacken und den INHALT des Ordners in ein Repository hochladen. Keine Datenbank, Passwörter oder .env hochladen. GitHub speichert den Code; GitHub Pages allein führt diese Python-Anwendung nicht aus.

## Veröffentlichung
Benötigt einen Python-fähigen Hostingdienst und für dauerhaften Betrieb PostgreSQL. Keine feste Zusage eines kostenlosen Hostings: Angebote und Kontingente sind anbieterabhängig.

Umgebungsvariablen aus .env.example in der Hostingverwaltung setzen. Die Datei wird NICHT automatisch geladen. DEBUG=0, zufälliger SECRET_KEY, genaue ALLOWED_HOSTS und HTTPS-CSRF_TRUSTED_ORIGINS konfigurieren. SSL/HTTPS am Hosting aktivieren. Reverse-Proxy-Konfiguration ggf. anhand der konkreten Hostingumgebung prüfen; nicht blind Proxy-Header vertrauen.

Build: `pip install -r requirements.txt && python manage.py collectstatic --noinput`
Release: `python manage.py migrate`
Start: `gunicorn config.wsgi:application --bind 0.0.0.0:$PORT`
Einmalig per Hosting-Konsole `python manage.py seed` und `python manage.py createsuperuser` ausführen. Neue Tage im Admin planen. Der Seed-Befehl erstellt nur sieben Tage und wiederholt teilweise Kategorien; er ist kein dauerhaft redaktioneller Fragenservice.

## Tagesbetrieb
Der Server verwendet Europe/Berlin. Vergangene Versuche werden beim nächsten Seitenaufruf geschlossen. Dafür ist kein Scheduler nötig. Fehlende Antworten zählen 0; abgeschlossene Tagesversuche zählen für Streaks. Historische Ergebnisse über `/ergebnis/?tag=2026-11-13` abrufbar, sofern ein eigener abgeschlossener Versuch besteht.

## Ehrliche Grenzen und noch offene Arbeit
- Gastkennung liegt in einer Django-Sitzung. Cookies löschen, anderes Gerät oder mehrere Konten können die Sperre umgehen. Keine Garantie „ein Mensch pro Tag“.
- Bestehende Kontoversuche haben bei Gastübernahme Vorrang; es wird kein besseres Ergebnis ausgewählt.
- Fragen/Antworten sind Demo-Inhalte. Seltenheitswerte sind Einschätzungen, keine gemessenen Bevölkerungsdaten. Einige Kategorien haben nur wenige Antworten; dadurch sind nicht alle Stufen vertreten.
- Fragen/Antwortwerte werden pro Tag separat angelegt; im laufenden Spiel NICHT bearbeiten. Eine technisch erzwungene unveränderliche Redaktionsfreigabe fehlt noch. Adminzugang nur vertrauenswürdigen Personen geben.
- Keine Passwort-Reset-E-Mails, E-Mail-Verifikation, Antwortreklamationen oder Konto-Löschoberfläche implementiert. Löschung zunächst durch Betreiber/Admin.
- Keine Anwendungslimits für Login-/Gast-/Antwortrequests eingebaut. Vor öffentlichem Betrieb Rate-Limits am Reverse-Proxy/Hosting und Monitoring ergänzen. Django allein verhindert keine Brute-Force-Anmeldungen.
- SQLite ausschließlich lokal. Nebenläufigkeitsgarantien mit PostgreSQL vor öffentlichem Betrieb lasttesten.
- Kein Mitternachts-Countdown, keine vollständige administrative Statistik, keine automatische Fragenrecherche.
- Impressum/Datenschutzhinweise, Löschfristen, Hostingverträge, Backups und Sicherheitsprüfung vor öffentlichem Betrieb ergänzen. Datenschutzerklärung muss die tatsächliche Infrastruktur abbilden.
- Anonyme Player-Datensätze entstehen beim Besuch. Bereinigung alter ungenutzter Profile ist noch zu ergänzen.

## Tests
`python manage.py test` (DEBUG=1 für lokale Entwicklung setzen).
Enthalten sind Basistests für Normalisierung, Rundendurchlauf, doppeltes Absenden und Zukunftsfilter. Noch keine umfassenden Parallelitäts-, DST-, Kontoübernahme- oder Browser-/Barrierefreiheitstests. Siehe PRUEFSTATUS.md für tatsächlich ausgeführte Prüfungen dieses Lieferumfangs.
